ctrans_start = '@x'
ctrans_trans = '@y'
ctrans_end   = '@z'
ctrans_ext   = '.trn'
ctrans_cmnt  = '%'
excl_list = ['image/jpeg', 'image/png']
